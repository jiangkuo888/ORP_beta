var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings =
[
    [ "ContinueButtonMode", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#ab9739c17b45aca7244295889504e0c1e", [
      [ "Never", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#ab9739c17b45aca7244295889504e0c1ea6e7b34fa59e1bd229b207892956dc41c", null ],
      [ "Always", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#ab9739c17b45aca7244295889504e0c1ea68eec46437c384d8dad18d5464ebc35c", null ],
      [ "OptionalBeforeResponseMenu", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#ab9739c17b45aca7244295889504e0c1ead5dd2611e7c175354aca4cca20b2760d", null ],
      [ "NotBeforeResponseMenu", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#ab9739c17b45aca7244295889504e0c1eadd541e017c63311191af9146d21595c6", null ]
    ] ],
    [ "continueButton", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a97286d50d8257c735feb60b86eeb8a47", null ],
    [ "informSequenceStartAndEnd", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a5d0bc1a67457b746525c454f2a6a488f", null ],
    [ "minSubtitleSeconds", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a34d2da71c3eaf9a40b195b89aa32fcd9", null ],
    [ "richTextEmphases", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a214ea3f0fc04a00d76d2e2298d355f69", null ],
    [ "showNPCSubtitlesDuringLine", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a13af2acc41b92ea29475a57b049c6a3d", null ],
    [ "showNPCSubtitlesWithResponses", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#a3d3d7703c626084d7718029e3cfadf4f", null ],
    [ "showPCSubtitlesDuringLine", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#acdcc2810c08bd6330143790e4194c437", null ],
    [ "subtitleCharsPerSecond", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html#afacb25ca007db79b932de7b30aab152d", null ]
];