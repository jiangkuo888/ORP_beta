var class_pixel_crushers_1_1_dialogue_system_1_1_bark_starter =
[
    [ "TryBark", "class_pixel_crushers_1_1_dialogue_system_1_1_bark_starter.html#a7a05d9300978431854505c75ebfb33fe", null ],
    [ "allowDuringConversations", "class_pixel_crushers_1_1_dialogue_system_1_1_bark_starter.html#a7f4634651898b1f52f2a5dae09611e87", null ],
    [ "barkOrder", "class_pixel_crushers_1_1_dialogue_system_1_1_bark_starter.html#ae27f89912d51fa1fdec1edb954b85f31", null ]
];