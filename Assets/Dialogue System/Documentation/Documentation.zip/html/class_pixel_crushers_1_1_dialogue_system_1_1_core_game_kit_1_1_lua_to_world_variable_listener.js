var class_pixel_crushers_1_1_dialogue_system_1_1_core_game_kit_1_1_lua_to_world_variable_listener =
[
    [ "frequency", "class_pixel_crushers_1_1_dialogue_system_1_1_core_game_kit_1_1_lua_to_world_variable_listener.html#af62b93f11e25c435df4144fe7875edd7", null ],
    [ "worldVariables", "class_pixel_crushers_1_1_dialogue_system_1_1_core_game_kit_1_1_lua_to_world_variable_listener.html#aff444ef752fd211918e978af04f4dd16", null ]
];