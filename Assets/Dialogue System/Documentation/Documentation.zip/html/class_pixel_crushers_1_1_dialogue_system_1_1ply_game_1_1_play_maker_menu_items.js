var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_play_maker_menu_items =
[
    [ "AddComponentConversationController", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_play_maker_menu_items.html#a86c16d6aacf86b16025f8734fd6027d9", null ],
    [ "AddComponentPersistableDialogueManager", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_play_maker_menu_items.html#a3facc7ba42361e1eb6823c70b9e53b8f", null ]
];