var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_preload_dialogue_u_i__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_preload_dialogue_u_i__ply_block.html#a4953ceaae6858c512b0be92d1670d72d", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_preload_dialogue_u_i__ply_block.html#ac4a074ffd69268c2280a577471e8cccc", null ]
];