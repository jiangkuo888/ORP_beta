var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref =
[
    [ "ConnectionRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref.html#a0978464ff319d7d345f4f5c811e43ee4", null ],
    [ "ConnectionRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref.html#a224ae673e404b4530f86e7a1f37a47b5", null ],
    [ "idRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref.html#ad78cb073d5a8dd39979a962d9bc95f7d", null ],
    [ "pinRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_connection_ref.html#a28922a9a94c1cf15a3a1f96f6e2dfcfd", null ]
];