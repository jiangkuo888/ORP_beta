var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings =
[
    [ "alwaysForceResponseMenu", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html#a17f9d08a59feb0c7743620811b7d8fdc", null ],
    [ "cancel", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html#a5614e8f4308a5390aa04d55cd98e2dc7", null ],
    [ "qteButtons", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html#a7b394b3ee0ff4d8f61c5fac882cdd803", null ],
    [ "responseTimeout", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html#aa19f689dd0b4de6b20a61995fe6eb07c", null ],
    [ "responseTimeoutAction", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html#a80642c7e0e3a84a04895e8cf3ac1505e", null ]
];