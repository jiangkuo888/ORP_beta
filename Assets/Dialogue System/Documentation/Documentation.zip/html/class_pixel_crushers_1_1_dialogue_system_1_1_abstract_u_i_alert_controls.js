var class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_alert_controls =
[
    [ "SetMessage", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_alert_controls.html#a1b0520e4168eadb93f4302fd50d2401b", null ],
    [ "ShowMessage", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_alert_controls.html#ac44cf8415f2efb2309b022234a9744ea", null ],
    [ "alertDoneTime", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_alert_controls.html#afe449ecaf4a3c007cc12575d853742f4", null ],
    [ "IsDone", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_alert_controls.html#a4e53b966d87a38623cd0e1818269c850", null ],
    [ "IsVisible", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_alert_controls.html#a12f4d577b7dbb104fdd8146cb29943ff", null ]
];