var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_quest_entry_description__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_quest_entry_description__ply_block.html#aa831c2eae179699674634cded57af7a7", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_quest_entry_description__ply_block.html#a27c078c6bc74ea63dcfc0b2e0bb6f6b2", null ],
    [ "entryNumber", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_quest_entry_description__ply_block.html#ab53159747844b689b0f2c30433d55a29", null ],
    [ "questState", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_quest_entry_description__ply_block.html#a62ac053b31b2ec36861979ab9d5f1978", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_set_quest_entry_description__ply_block.html#acceade41e258c20a0d86851832886618", null ]
];