var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_location =
[
    [ "Fields", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_location.html#af7e974b4d0e8a80ebaf00281d01084bf", null ],
    [ "ID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_location.html#a2726a76d85bee0b8e37b6e464093b15e", null ]
];