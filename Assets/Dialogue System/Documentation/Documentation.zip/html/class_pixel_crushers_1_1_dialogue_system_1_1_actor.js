var class_pixel_crushers_1_1_dialogue_system_1_1_actor =
[
    [ "Actor", "class_pixel_crushers_1_1_dialogue_system_1_1_actor.html#a763769dd1f695e11e4f164ba5a5b7729", null ],
    [ "Actor", "class_pixel_crushers_1_1_dialogue_system_1_1_actor.html#aa3c408c0e843ddf7b3335a4c3fcd4ac6", null ],
    [ "Assign", "class_pixel_crushers_1_1_dialogue_system_1_1_actor.html#aa387f6251000ab6330f650211fe9054f", null ],
    [ "portrait", "class_pixel_crushers_1_1_dialogue_system_1_1_actor.html#af27436c8292fbab57f3ef01438b40548", null ],
    [ "IsPlayer", "class_pixel_crushers_1_1_dialogue_system_1_1_actor.html#ae1887ac4be2300350a59a26b9dfbb84f", null ],
    [ "TextureName", "class_pixel_crushers_1_1_dialogue_system_1_1_actor.html#a9a6bc5de674bdd5f7bd8c1d47b68427b", null ]
];