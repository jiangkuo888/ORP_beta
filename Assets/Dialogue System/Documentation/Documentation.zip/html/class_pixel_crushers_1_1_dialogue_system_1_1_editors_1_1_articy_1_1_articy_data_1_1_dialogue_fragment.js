var class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment =
[
    [ "DialogueFragment", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html#adfeaf402f11a8986776ee030b487cdfa", null ],
    [ "DialogueFragment", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html#a5fb223b40a030cb2f8c494d26c2aa9d0", null ],
    [ "menuText", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html#a914b221671d6121a129c87c7a6765cc0", null ],
    [ "pins", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html#a24cefdcc117b44d42c3c2ce9b5cfbd39", null ],
    [ "speakerIdRef", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html#a28b158f48255d1b01e3067d05cec68d5", null ],
    [ "stageDirections", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_articy_data_1_1_dialogue_fragment.html#adbfea660122d6ec0f5c2c60a8a1e518b", null ]
];