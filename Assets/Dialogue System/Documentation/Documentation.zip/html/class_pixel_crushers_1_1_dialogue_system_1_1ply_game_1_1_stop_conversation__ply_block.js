var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_stop_conversation__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_stop_conversation__ply_block.html#af06c28886b57b621f0f56c4e997390a3", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_stop_conversation__ply_block.html#ab9fd6531e92ca148c1773b6961bd33e3", null ]
];