var class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_root =
[
    [ "Hide", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_root.html#af014447ffcf62d62bafeefdc5d3d5e3d", null ],
    [ "Show", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_root.html#a17bc5846d8c913cae74171787e3a2ea0", null ]
];