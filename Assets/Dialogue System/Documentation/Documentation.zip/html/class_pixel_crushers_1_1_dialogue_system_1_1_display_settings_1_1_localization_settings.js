var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings =
[
    [ "language", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings.html#a84c98f93129dcba2786d6bdb96656d80", null ],
    [ "useSystemLanguage", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings.html#a9168a0a00bd6b3c9bc08c9fa3a339745", null ]
];