var class_pixel_crushers_1_1_dialogue_system_1_1_database_merger =
[
    [ "ConflictingIDRule", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52", [
      [ "AllowConflictingIDs", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52a43faa6d3eee581b3e5679f7c80b43242", null ],
      [ "AssignUniqueIDs", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52aa618bfcec7d5472eaa98cacc2bf931ad", null ]
    ] ],
    [ "Merge", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#a740481a63c1289ae4d2d1fa448770243", null ]
];