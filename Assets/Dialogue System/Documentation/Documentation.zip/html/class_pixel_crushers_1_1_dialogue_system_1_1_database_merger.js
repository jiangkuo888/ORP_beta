var class_pixel_crushers_1_1_dialogue_system_1_1_database_merger =
[
    [ "ConflictingIDRule", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52", [
      [ "Add", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52aec211f7c20af43e742bf2570c3cb84f9", null ],
      [ "DoNotAdd", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52a05360195bf8a3679217a28442eede525", null ],
      [ "AssignUniqueID", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#ada48b6e7925df746700b2f5d4a172c52a0b3f332debf7a3c03b9d4662c1036116", null ]
    ] ],
    [ "Merge", "class_pixel_crushers_1_1_dialogue_system_1_1_database_merger.html#a740481a63c1289ae4d2d1fa448770243", null ]
];