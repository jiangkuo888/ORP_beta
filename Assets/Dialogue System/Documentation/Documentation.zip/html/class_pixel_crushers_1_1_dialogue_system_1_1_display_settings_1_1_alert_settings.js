var class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings =
[
    [ "alertCheckFrequency", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings.html#a1caf7c0099e03aa75660efd9ed0dcac7", null ],
    [ "allowAlertsDuringConversations", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings.html#a8ccb755dd2aaff81c2f269351cbd2f12", null ]
];