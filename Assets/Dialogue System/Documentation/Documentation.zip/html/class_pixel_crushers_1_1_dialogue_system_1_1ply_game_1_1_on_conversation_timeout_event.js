var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_conversation_timeout_event =
[
    [ "HandlerType", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_on_conversation_timeout_event.html#acfe6d7d000bb6a0d8e99b9107d453cf7", null ]
];